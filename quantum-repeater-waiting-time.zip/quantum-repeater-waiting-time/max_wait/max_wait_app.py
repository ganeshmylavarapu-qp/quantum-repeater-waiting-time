import io
import math
import random
import itertools
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import networkx as nx
import numpy as np
import pandas as pd
import streamlit as st


# ======================================================
# PAGE CONFIG
# ======================================================

st.set_page_config(page_title="Quantum Repeater Network Simulator", layout="wide")
st.title("Quantum Repeater Network Simulator")


# ======================================================
# SIDEBAR INPUTS
# ======================================================

st.sidebar.title("Network Parameters")

n_nodes = st.sidebar.slider("Number of nodes", 3, 50, 5)
total_distance = st.sidebar.number_input("Total distance (km)", min_value=1.0, value=250.0)
distance_per_link = total_distance / (n_nodes - 1)
st.sidebar.markdown(f"*Link distance: {distance_per_link:.2f} km (total / (nodes-1))*")
alpha = st.sidebar.number_input("Fiber loss α (dB/km)", min_value=0.0, value=0.21)

m = st.sidebar.number_input("Multiplexing modes m", min_value=1, value=1000)
delta_t_unit = st.sidebar.number_input("Δt unit (ms)", min_value=0.0, value=0.1)
T = st.sidebar.number_input("Memory coherence time T (ms)", min_value=1.0, value=200.0)

eta_d1 = st.sidebar.number_input("η_d1", min_value=0.0, max_value=1.0, value=0.9)
eta_d2 = st.sidebar.number_input("η_d2", min_value=0.0, max_value=1.0, value=0.9)
rho = st.sidebar.number_input("ρ", min_value=0.0, max_value=1.0, value=0.9)
eta_mem = st.sidebar.number_input("η_mem", min_value=0.0, max_value=1.0, value=0.9)

model_type = st.sidebar.selectbox("Model Type", ["Model 0","Model 1", "Model 2"])
network_type = st.sidebar.selectbox("Network Type", ["Intercity (Chain)", "Intracity (Star)"])
fiber_index = st.sidebar.number_input("Fiber refractive index", min_value=1.0, value=1.5)

st.sidebar.markdown("---")
st.sidebar.subheader("Order Search")
max_exact_orders = st.sidebar.number_input("Max exact reduced orders", min_value=10, value=100000, step=10)
sample_orders = st.sidebar.number_input("Sampled reduced orders (fallback)", min_value=10, value=300, step=10)
random_seed = st.sidebar.number_input("Random seed", min_value=0, value=7, step=1)

st.sidebar.markdown("---")
st.sidebar.subheader("Sweep Settings")
mode_values_text = st.sidebar.text_input("Modes sweep values", "1,10,50,100,500")
delta_count = st.sidebar.slider("Δt sweep points", 5, 60, 30)
delta_max = st.sidebar.number_input("Δt sweep max (ms)", min_value=0.1, value=200.0)

st.sidebar.markdown("---")
st.sidebar.subheader("Multi-Node Star Sweep")
multi_node_values_text = st.sidebar.text_input("Node counts for Star sweep", "5,10,20,30,40,50")

st.sidebar.markdown("---")
st.sidebar.subheader("Model Comparison Settings")
m_comparison = st.sidebar.number_input("Modes m for Model comparison", min_value=1, value=10, step=1)
st.sidebar.markdown("*Use small m (e.g. 10) to see difference between Model 1 and Model 2*")

st.sidebar.markdown("---")
st.sidebar.subheader("Model 0 Quantum Advantage Zone")

qa_link_distance_min = st.sidebar.number_input(
    "QA link distance min (km)", min_value=1.0, value=5.0, key="qa_link_distance_min")
qa_link_distance_max = st.sidebar.number_input(
    "QA link distance max (km)", min_value=qa_link_distance_min, value=200.0, key="qa_link_distance_max")
qa_link_distance_points = st.sidebar.slider(
    "QA link distance sweep points", 5, 80, 30, key="qa_link_distance_points")

qa_delta_t_min = st.sidebar.number_input(
    "QA Δt min (ms)", min_value=0.0, value=0.0, key="qa_delta_t_min")
qa_delta_t_max = st.sidebar.number_input(
    "QA Δt max (ms)", min_value=qa_delta_t_min + 0.1, value=100.0, key="qa_delta_t_max")
qa_delta_t_points = st.sidebar.slider(
    "QA Δt sweep points", 5, 80, 30, key="qa_delta_t_points")


# ======================================================
# HELPERS
# ======================================================

COLOR_CHAIN_MAX = "orange"
COLOR_CHAIN_MIN = "blue"
COLOR_STAR = "green"


def parse_mode_values(text: str):
    vals = []
    for part in text.split(","):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [1, 10, 50, 100, 500]


def apply_normal_axis_format(ax):
    ax.ticklabel_format(style="plain", axis="y")
    ax.yaxis.get_major_formatter().set_useOffset(False)
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter("%.6f"))


mode_values = parse_mode_values(mode_values_text)
delta_values = np.linspace(0.1, float(delta_max), int(delta_count))

def parse_node_values(text: str):
    vals = []
    for part in text.split(","):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [5, 10, 20, 30, 40, 50]

multi_node_values = parse_node_values(multi_node_values_text)


# ======================================================
# IMAGE SECTION
# ======================================================

st.subheader("Quantum Repeater Architecture")

image_path = Path("repeater_architecture.png")
if image_path.exists():
    st.image(
        str(image_path),
        caption=(
            "Reference quantum repeater architecture used for conceptual illustration. "
            "Photons travel L/2 to the BSM stations, while repeater nodes perform memory storage and swapping."
        ),
        use_container_width=True,
    )
else:
    st.info(
        "Place your image in the same folder as app.py with the filename "
        "`repeater_architecture.png` to display it here."
    )


# ======================================================
# PRA-STYLE MODEL DESCRIPTION
# ======================================================

st.subheader("Physical Model")

st.markdown(r"""
### Maximum waiting-time convention
For all paper/comparison runs in this frozen version, the intrinsic baseline storage time is fixed to

$$t_0=0.$$

Let $n$ denote the number of elementary links in the selected path. Therefore the number of entanglement-swapping operations is $n-1$, and for both Models 1 and 2

$$
p_{\mathrm{swap}}=(\eta_{\mathrm{mem}}\eta_{d2})^{2(n-1)}.
$$

If $w_{\max}$ is the maximum repeater waiting count assigned to the path, the same maximum waiting interval is applied to each of the $n$ elementary-link memory factors. Thus

$$
p_{\mathrm{werner}}=p_{\mathrm{success}}\exp\!\left[-\frac{n\,w_{\max}\Delta t}{T}\right],
$$

and

$$
F=\frac{1+p_{\mathrm{werner}}}{2}.
$$

There is no additional $n$th power on the already path-level success probability.
""")

if model_type == "Model 0":
    st.markdown(r"""
### Model 0 — Decoherence-only reference

$$p_{\mathrm{elem}}=p_{\mathrm{swap}}=p_{\mathrm{success}}=1.$$

Only maximum-wait memory decoherence contributes to the fidelity.
""")
elif model_type == "Model 1":
    st.markdown(r"""
### Model 1 — Network-wide link generation

For a single elementary link,

$$p=\eta_{d1}^{2}\rho^{2}10^{-\alpha L/10},\qquad
p_{\mathrm{elem}}=1-(1-p)^m.$$

For an $N$-node network and a selected path containing $n$ elementary links,

$$
p_{\mathrm{success}}=(p_{\mathrm{elem}})^{N-1}
(\eta_{\mathrm{mem}}\eta_{d2})^{2(n-1)}.
$$
""")
else:
    st.markdown(r"""
### Model 2 — Path-dependent link generation

For a single elementary link,

$$p=\eta_{d1}^{2}\rho^{2}10^{-\alpha L/10},\qquad
p_{\mathrm{elem}}=1-(1-p)^m.$$

For a selected path containing $n$ elementary links,

$$
p_{\mathrm{success}}=(p_{\mathrm{elem}})^n
(\eta_{\mathrm{mem}}\eta_{d2})^{2(n-1)}.
$$
""")

# ======================================================
# TOPOLOGY CONSTRUCTION
# ======================================================

def create_chain(n):
    G = nx.Graph()
    for i in range(1, n):
        G.add_edge(i, i + 1)
    return G


def create_star(n):
    G = nx.Graph()
    center = 1
    for i in range(2, n + 1):
        G.add_edge(center, i)
    return G


def get_positions(graph, topology_name):
    if topology_name == "chain":
        return {node: (idx, 0.0) for idx, node in enumerate(sorted(graph.nodes()), start=1)}
    return nx.spring_layout(graph, seed=7)


def draw_topology(graph, topology_name):
    fig, ax = plt.subplots(figsize=(6, 3.8))
    pos = get_positions(graph, topology_name)
    nx.draw(
        graph,
        pos,
        with_labels=True,
        node_size=900,
        node_color="#cfe3ef",
        edge_color="#4f5b66",
        width=2,
        font_size=11,
        ax=ax,
    )
    ax.set_title(f"{topology_name.capitalize()} Topology")
    ax.axis("off")
    fig.tight_layout()
    return fig


# ======================================================
# MODEL FUNCTIONS
# ======================================================

def compute_t0_ms(distance_per_link_km, fiber_index_value):
    c = 3.0e8
    v = c / fiber_index_value
    d_m = distance_per_link_km * 1000.0
    photon_distance_m = d_m / 2.0
    return (photon_distance_m / v) * 1000.0


def get_all_paths(graph):
    pairs = list(itertools.combinations(sorted(graph.nodes()), 2))
    return [(u, v, nx.shortest_path(graph, u, v)) for u, v in pairs]


def evaluate_order(ordered_paths):
    node_wait = {}
    rows = []

    for idx, (u, v, p) in enumerate(ordered_paths, start=1):
        intermediate = p[1:-1]
        waits = []
        contrib = {}

        for node in intermediate:
            w = node_wait.get(node, 0)
            waits.append(w)
            contrib[node] = w
            node_wait[node] = w + 1

        max_wait = max(waits) if waits else 0

        rows.append(
            {
                "order": idx,
                "pair": (u, v),
                "path_nodes": p,
                "path": "->".join(map(str, p)),
                "links": len(p) - 1,
                "waiting": max_wait,
                "waiting_contribution": contrib,
            }
        )

    return rows

def compute_probabilities(n_links, m_value, n_nodes_value, distance_per_link_value, model_name,
                          alpha_value=None, eta_d1_value=None, eta_d2_value=None,
                          rho_value=None, eta_mem_value=None):
    _alpha   = alpha_value   if alpha_value   is not None else alpha
    _eta_d1  = eta_d1_value  if eta_d1_value  is not None else eta_d1
    _eta_d2  = eta_d2_value  if eta_d2_value  is not None else eta_d2
    _rho     = rho_value     if rho_value     is not None else rho
    _eta_mem = eta_mem_value if eta_mem_value is not None else eta_mem

    if model_name == "Model 0":
        p_single = 1.0
        p_elem = 1.0
        p_swap = 1.0
        p_success = 1.0
        return p_single, p_elem, p_swap, p_success

    p_single = (_eta_d1 ** 2) * (_rho ** 2) * 10 ** (-_alpha * distance_per_link_value / 10)
    p_elem = 1 - (1 - p_single) ** m_value
    #p_swap = ((_eta_mem * _eta_d2) ** (2 * (n_links - 1))) / (2 ** (n_links - 1))
    if n_links == 1:
        p_swap = 1.0
    else:
        p_swap = ((_eta_mem * _eta_d2) ** (2 * (n_links - 1)))

    if model_name == "Model 1":
        n_elem = n_nodes_value - 1
        p_success = (p_elem ** n_elem) * p_swap
    else:
        p_success = (p_elem ** n_links) * p_swap

    return p_single, p_elem, p_swap, p_success


def compute_fidelity(p_success, n_links, waiting, delta_t_unit_value, t0_ms, T_ms):
    delta_t_ms = waiting * delta_t_unit_value
    exponent_component = (t0_ms + delta_t_ms) / T_ms
    exp_term = math.exp(-exponent_component)
    # p_success is already a path-level quantity (it already contains p_elem**n and p_swap).
    # Apply the common max-wait decoherence to each of the n elementary-link factors,
    # but DO NOT raise p_success itself to n again.
    p_werner = p_success * (exp_term ** n_links)
    fidelity = (1 + p_werner) / 2
    return fidelity, delta_t_ms, exponent_component, exp_term, p_werner


def make_table(order_rows, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, t0_value, T_value, model_name,
               alpha_value=None, eta_d1_value=None, eta_d2_value=None, rho_value=None, eta_mem_value=None):
    final_rows = []

    for r in order_rows:
        p_single, p_elem, p_swap, p_success = compute_probabilities(
            r["links"],
            m_value,
            n_nodes_value,
            distance_per_link_value,
            model_name,
            alpha_value=alpha_value,
            eta_d1_value=eta_d1_value,
            eta_d2_value=eta_d2_value,
            rho_value=rho_value,
            eta_mem_value=eta_mem_value,
        )

        fidelity, delta_t_ms, exponent_component, exp_term, p_werner = compute_fidelity(
            p_success=p_success,
            n_links=r["links"],
            waiting=r["waiting"],
            delta_t_unit_value=delta_t_unit_value,
            t0_ms=t0_value,
            T_ms=T_value,
        )

        final_rows.append(
            {
                "m": m_value,
                "order": r["order"],
                "pair": str(r["pair"]),
                "path": r["path"],
                "links": r["links"],
                "waiting": r["waiting"],
                "waiting_contribution": str(r["waiting_contribution"]),
                "t0_ms": t0_value,
                "delta_t_ms": delta_t_ms,
                "t0_plus_delta_over_T": exponent_component,
                "exp_term": exp_term,
                "p_single": p_single,
                "p_elem": p_elem,
                "p_swap": p_swap,
                "p_success": p_success,
                "p_werner": p_werner,
                "fidelity": fidelity,
                "raw_path_nodes": r["path_nodes"],
            }
        )

    return pd.DataFrame(final_rows)


def split_zero_and_conflict_paths(paths):
    zero_wait = []
    conflict = []

    for item in paths:
        _, _, p = item
        if len(p) <= 2:
            zero_wait.append(item)
        else:
            conflict.append(item)

    zero_wait = tuple(sorted(zero_wait, key=lambda x: (x[0], x[1])))
    conflict = tuple(sorted(conflict, key=lambda x: (x[0], x[1])))
    return zero_wait, conflict


def build_reduced_orders(paths, max_exact, sample_count, seed):
    zero_wait, conflict = split_zero_and_conflict_paths(paths)
    n_conflict = len(conflict)
    total_exact = math.factorial(n_conflict)

    if total_exact <= max_exact:
        orders = [list(zero_wait) + list(perm) for perm in itertools.permutations(conflict)]
        return orders, "exact_reduced", len(zero_wait), len(conflict)

    rng = random.Random(seed)
    seen = set()
    sampled = []

    base = tuple(c[0] for c in conflict)
    rev  = tuple(c[0] for c in reversed(conflict))

    for key, cand in [(base, list(conflict)), (rev, list(reversed(conflict)))]:
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + cand)

    attempts = 0
    max_attempts = sample_count * 20
    while len(sampled) < sample_count and attempts < max_attempts:
        attempts += 1
        arr = list(conflict)
        rng.shuffle(arr)
        key = tuple(c[0] for c in arr)
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + arr)

    return sampled, f"sampled_reduced_{len(sampled)}", len(zero_wait), len(conflict)




@st.cache_data(show_spinner=False)
def model0_quantum_advantage_zone_cached(
    topology_name,
    link_distance_tuple,
    delta_tuple,
    m_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    max_exact,
    sample_count,
    seed,
    ):
    """
    Fixed 5-node quantum advantage map for Model 0.
    Sweeps:
      - distance per adjacent link
      - delta_t_unit
    Checks whether average fidelity exceeds 2/3.
    """

    n_nodes_fixed = 5
    threshold = 2.0 / 3.0

    fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    adv_fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)
    adv_fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)

    for i, dt in enumerate(delta_tuple):
        for j, d_link in enumerate(link_distance_tuple):
            res = evaluate_topology_for_one_delta_cached(
                topology_name=topology_name,
                n_nodes_value=n_nodes_fixed,
                m_value=m_value,
                distance_per_link_value=float(d_link),
                delta_t_unit_value=float(dt),
                T_value=T_value,
                alpha_value=alpha_value,
                eta_d1_value=eta_d1_value,
                eta_d2_value=eta_d2_value,
                rho_value=rho_value,
                eta_mem_value=eta_mem_value,
                fiber_index_value=fiber_index_value,
                model_name="Model 0",
                max_exact=max_exact,
                sample_count=sample_count,
                seed=seed,
            )

            if topology_name == "star":
                favg = res["favg"]
                fmax_grid[i, j] = favg
                fmin_grid[i, j] = favg
                adv_fmax_grid[i, j] = 1 if favg > threshold else 0
                adv_fmin_grid[i, j] = 1 if favg > threshold else 0
            else:
                fmax_grid[i, j] = res["fmax"]
                fmin_grid[i, j] = res["fmin"]
                adv_fmax_grid[i, j] = 1 if res["fmax"] > threshold else 0
                adv_fmin_grid[i, j] = 1 if res["fmin"] > threshold else 0

    return fmax_grid, fmin_grid, adv_fmax_grid, adv_fmin_grid

def evaluate_topology_for_one_delta_cached(
    topology_name,
    n_nodes_value,
    m_value,
    distance_per_link_value,
    delta_t_unit_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    model_name,
    max_exact,
    sample_count,
    seed,
):
    graph = create_chain(n_nodes_value) if topology_name == "chain" else create_star(n_nodes_value)
    paths = get_all_paths(graph)

    orders, eval_mode, zero_count, conflict_count = build_reduced_orders(
        paths,
        int(max_exact),
        int(sample_count),
        int(seed),
    )

    t0_value = compute_t0_ms(distance_per_link_value, fiber_index_value)

    all_avgF = []
    all_tables = []

    for order in orders:
        rows = evaluate_order(order)
        df = make_table(
            rows,
            n_nodes_value,
            m_value,
            distance_per_link_value,
            delta_t_unit_value,
            t0_value,
            T_value,
            model_name,
            alpha_value=alpha_value,
            eta_d1_value=eta_d1_value,
            eta_d2_value=eta_d2_value,
            rho_value=rho_value,
            eta_mem_value=eta_mem_value,
        )
        avgF = float(df["fidelity"].mean())
        all_avgF.append(avgF)
        all_tables.append(df)

    if topology_name == "star":
        avg_val = float(np.mean(all_avgF))
        avg_df = all_tables[int(np.argmax(all_avgF))]
        return {
            "favg": avg_val,
            "fmax": avg_val,
            "fmin": avg_val,
            "best_df": avg_df,
            "worst_df": avg_df,
            "eval_mode": "single_average_star",
            "orders_evaluated": len(all_avgF),
            "zero_paths": zero_count,
            "conflict_paths": conflict_count,
        }

    best_idx = int(np.argmax(all_avgF))
    worst_idx = int(np.argmin(all_avgF))

    return {
        "fmax": all_avgF[best_idx],
        "fmin": all_avgF[worst_idx],
        "best_df": all_tables[best_idx],
        "worst_df": all_tables[worst_idx],
        "eval_mode": eval_mode,
        "orders_evaluated": len(orders),
        "zero_paths": zero_count,
        "conflict_paths": conflict_count,
    }

@st.cache_data(show_spinner=False)
def modes_sweep_cached(
    topology_name,
    modes_tuple,
    n_nodes_value,
    distance_per_link_value,
    delta_t_unit_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    model_name,
    max_exact,
    sample_count,
    seed,
):
    best_vals = []
    worst_vals = []

    for mm in modes_tuple:
        res = evaluate_topology_for_one_delta_cached(
            topology_name,
            n_nodes_value,
            int(mm),
            distance_per_link_value,
            delta_t_unit_value,
            T_value,
            alpha_value,
            eta_d1_value,
            eta_d2_value,
            rho_value,
            eta_mem_value,
            fiber_index_value,
            model_name,
            max_exact,
            sample_count,
            seed,
        )
        best_vals.append(res["fmax"])
        worst_vals.append(res["fmin"])

    return best_vals, worst_vals


@st.cache_data(show_spinner=False)
def delta_sweep_cached(
    topology_name,
    deltas_tuple,
    n_nodes_value,
    m_value,
    distance_per_link_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    model_name,
    max_exact,
    sample_count,
    seed,
):
    best_vals = []
    worst_vals = []

    for dt in deltas_tuple:
        res = evaluate_topology_for_one_delta_cached(
            topology_name,
            n_nodes_value,
            m_value,
            distance_per_link_value,
            float(dt),
            T_value,
            alpha_value,
            eta_d1_value,
            eta_d2_value,
            rho_value,
            eta_mem_value,
            fiber_index_value,
            model_name,
            max_exact,
            sample_count,
            seed,
        )
        best_vals.append(res["fmax"])
        worst_vals.append(res["fmin"])

    return best_vals, worst_vals


@st.cache_data(show_spinner=False)
def multi_node_delta_sweep_cached(
    node_counts_tuple,
    deltas_tuple,
    m_value,
    total_distance_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    model_name,
    max_exact,
    sample_count,
    seed,
):
    """For each node count, compute star average fidelity across delta_t values."""
    results = {}
    for n in node_counts_tuple:
        dist_per_link = total_distance_value / (n - 1)
        star_vals, _ = delta_sweep_cached(
            "star",
            deltas_tuple,
            n,
            m_value,
            dist_per_link,
            T_value,
            alpha_value,
            eta_d1_value,
            eta_d2_value,
            rho_value,
            eta_mem_value,
            fiber_index_value,
            model_name,
            max_exact,
            sample_count,
            seed,
        )
        results[n] = star_vals
    return results


@st.cache_data(show_spinner=False)
def model_comparison_delta_sweep_cached(
    topology_name,
    deltas_tuple,
    n_nodes_value,
    m_value,
    distance_per_link_value,
    T_value,
    alpha_value,
    eta_d1_value,
    eta_d2_value,
    rho_value,
    eta_mem_value,
    fiber_index_value,
    max_exact,
    sample_count,
    seed,
):
    """Compute delta sweep for Model 0, Model 1, and Model 2 for comparison."""
    best_m0, worst_m0 = delta_sweep_cached(
        topology_name, deltas_tuple, n_nodes_value, m_value,
        distance_per_link_value, T_value, alpha_value, eta_d1_value,
        eta_d2_value, rho_value, eta_mem_value, fiber_index_value,
        "Model 0", max_exact, sample_count, seed,
    )
    best_m1, worst_m1 = delta_sweep_cached(
        topology_name, deltas_tuple, n_nodes_value, m_value,
        distance_per_link_value, T_value, alpha_value, eta_d1_value,
        eta_d2_value, rho_value, eta_mem_value, fiber_index_value,
        "Model 1", max_exact, sample_count, seed,
    )
    best_m2, worst_m2 = delta_sweep_cached(
        topology_name, deltas_tuple, n_nodes_value, m_value,
        distance_per_link_value, T_value, alpha_value, eta_d1_value,
        eta_d2_value, rho_value, eta_mem_value, fiber_index_value,
        "Model 2", max_exact, sample_count, seed,
    )
    return best_m0, worst_m0, best_m1, worst_m1, best_m2, worst_m2


def make_excel_bytes(sheets_dict):
    output = io.BytesIO()
    try:
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            for sheet_name, df in sheets_dict.items():
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        output.seek(0)
        return output.getvalue()
    except Exception:
        return None

# ======================================================
# P_success Vs Diatance
# ======================================================

def representative_path_links(topology_name, n_nodes_value):
    if topology_name == "chain":
        return n_nodes_value - 1
    else:
        # star: leaf-to-leaf via hub
        return 2 if n_nodes_value > 2 else 1


# ======================================================
# MAIN EVALUATION
# ======================================================

t0 = 0.0  # Paper/comparison convention: intrinsic t0 is fixed to zero

chain_graph = create_chain(n_nodes)
star_graph = create_star(n_nodes)

if network_type == "Intercity (Chain)":
    st.pyplot(draw_topology(chain_graph, "chain"), clear_figure=True)
else:
    st.pyplot(draw_topology(star_graph, "star"), clear_figure=True)

if network_type == "Intercity (Chain)":
    chain_res = evaluate_topology_for_one_delta_cached(
        "chain",
        n_nodes,
        m,
        distance_per_link,
        delta_t_unit,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        model_type,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )
    chain_fmax = chain_res["fmax"]
    chain_fmin = chain_res["fmin"]
    chain_df_max = chain_res["best_df"]
    chain_df_min = chain_res["worst_df"]
else:
    star_res = evaluate_topology_for_one_delta_cached(
        "star",
        n_nodes,
        m,
        distance_per_link,
        delta_t_unit,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        model_type,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )
    star_avg = star_res["favg"]
    star_df = star_res["best_df"]


# ======================================================
# SUMMARY
# ======================================================

st.subheader("Core Results")

p_single_now, p_elem_now, _, _ = compute_probabilities(1, m, n_nodes, distance_per_link, model_type)

if network_type == "Intercity (Chain)":
    c1, c2, c3 = st.columns(3)
    c1.metric("Chain Fmax", f"{chain_fmax:.6f}")
    c2.metric("Chain Fmin", f"{chain_fmin:.6f}")
    c3.metric("t0 (ms)", f"{t0:.6f}")
    st.write({
        "model": model_type,
        "network_type": network_type,
        "chain_eval_mode": chain_res["eval_mode"],
        "chain_orders_evaluated": chain_res["orders_evaluated"],
        "chain_zero_paths": chain_res["zero_paths"],
        "chain_conflict_paths": chain_res["conflict_paths"],
        "adjacent_link_p_single": p_single_now,
        "adjacent_link_p_elem": p_elem_now,
    })
else:
    c1, c2 = st.columns(2)
    c1.metric("Star Fidelity", f"{star_avg:.6f}")
    c2.metric("t0 (ms)", f"{t0:.6f}")
    st.write({
        "model": model_type,
        "network_type": network_type,
        "star_eval_mode": star_res["eval_mode"],
        "star_orders_evaluated": star_res["orders_evaluated"],
        "adjacent_link_p_single": p_single_now,
        "adjacent_link_p_elem": p_elem_now,
    })


# ======================================================
# SUMMARY BAR
# ======================================================

fig_bar, ax_bar = plt.subplots(figsize=(8, 5))
if network_type == "Intercity (Chain)":
    ax_bar.bar(
        ["Chain Fmax", "Chain Fmin"],
        [chain_fmax, chain_fmin],
        color=[COLOR_CHAIN_MAX, COLOR_CHAIN_MIN],
    )
    ax_bar.set_title("Intercity (Chain) — Fidelity Summary")
else:
    ax_bar.bar(
        ["Star"],
        [star_avg],
        color=[COLOR_STAR],
    )
    ax_bar.set_title("Intracity (Star) — Fidelity Summary")
ax_bar.set_ylabel("Average Fidelity")
ax_bar.grid(True, linestyle="--", alpha=0.3)
apply_normal_axis_format(ax_bar)
st.pyplot(fig_bar, clear_figure=True)


# ======================================================
# MODES SWEEP
# ======================================================

st.subheader("Average Fidelity vs Modes — Model 0 vs Model 1 vs Model 2")
st.caption(f"Δt fixed at {delta_t_unit} ms (sidebar value)")

if network_type == "Intercity (Chain)":
    # Model 0
    m0_chain_best, m0_chain_worst = modes_sweep_cached(
        "chain", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 0", int(max_exact_orders), int(sample_orders), int(random_seed),
    )
    # Model 1
    m1_chain_best, m1_chain_worst = modes_sweep_cached(
        "chain", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 1", int(max_exact_orders), int(sample_orders), int(random_seed),
    )
    # Model 2
    m2_chain_best, m2_chain_worst = modes_sweep_cached(
        "chain", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 2", int(max_exact_orders), int(sample_orders), int(random_seed),
    )

    fig_modes, ax_modes = plt.subplots(figsize=(10, 6))

    ax_modes.plot(mode_values, m0_chain_best,  marker="^", color="orange",     linestyle="-.", label="Model 0 — Chain Fmax")
    ax_modes.plot(mode_values, m0_chain_worst, marker="^", color="blue",       linestyle="-.", label="Model 0 — Chain Fmin")

    ax_modes.plot(mode_values, m1_chain_best,  marker="o", color="orange",     linestyle="-",  label="Model 1 — Chain Fmax")
    ax_modes.plot(mode_values, m1_chain_worst, marker="o", color="blue",       linestyle="-",  label="Model 1 — Chain Fmin")

    ax_modes.plot(mode_values, m2_chain_best,  marker="s", color="darkorange", linestyle="--", label="Model 2 — Chain Fmax")
    ax_modes.plot(mode_values, m2_chain_worst, marker="s", color="steelblue",  linestyle="--", label="Model 2 — Chain Fmin")

    ax_modes.set_xlabel("Modes (m)")
    ax_modes.set_ylabel("Average Fidelity")
    ax_modes.set_title(f"Intercity (Chain) — Model 0 vs Model 1 vs Model 2 (Δt={delta_t_unit} ms)")
    ax_modes.grid(True, linestyle="--", alpha=0.3)
    ax_modes.legend()
    apply_normal_axis_format(ax_modes)
    st.pyplot(fig_modes, clear_figure=True)

    df_modes = pd.DataFrame({
        "Modes": mode_values,
        "M0_Chain_Fmax": m0_chain_best, "M0_Chain_Fmin": m0_chain_worst,
        "M1_Chain_Fmax": m1_chain_best, "M1_Chain_Fmin": m1_chain_worst,
        "M2_Chain_Fmax": m2_chain_best, "M2_Chain_Fmin": m2_chain_worst,
    })

else:
    # Model 0
    m0_star_best, _ = modes_sweep_cached(
        "star", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 0", int(max_exact_orders), int(sample_orders), int(random_seed),
    )
    # Model 1
    m1_star_best, _ = modes_sweep_cached(
        "star", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 1", int(max_exact_orders), int(sample_orders), int(random_seed),
    )
    # Model 2
    m2_star_best, _ = modes_sweep_cached(
        "star", tuple(mode_values), n_nodes, distance_per_link,
        delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem,
        fiber_index, "Model 2", int(max_exact_orders), int(sample_orders), int(random_seed),
    )

    fig_modes, ax_modes = plt.subplots(figsize=(10, 6))

    ax_modes.plot(mode_values, m0_star_best, marker="^", color="green",     linestyle="-.", label="Model 0 — Star")
    ax_modes.plot(mode_values, m1_star_best, marker="o", color="green",     linestyle="-",  label="Model 1 — Star")
    ax_modes.plot(mode_values, m2_star_best, marker="s", color="darkgreen", linestyle="--", label="Model 2 — Star")

    ax_modes.set_xlabel("Modes (m)")
    ax_modes.set_ylabel("Average Fidelity")
    ax_modes.set_title(f"Intracity (Star) — Model 0 vs Model 1 vs Model 2 (Δt={delta_t_unit} ms)")
    ax_modes.grid(True, linestyle="--", alpha=0.3)
    ax_modes.legend()
    apply_normal_axis_format(ax_modes)
    st.pyplot(fig_modes, clear_figure=True)

    df_modes = pd.DataFrame({
        "Modes": mode_values,
        "M0_Star": m0_star_best,
        "M1_Star": m1_star_best,
        "M2_Star": m2_star_best,
    })

st.dataframe(df_modes, use_container_width=True)
st.download_button(
    "Download Modes Data (CSV)",
    df_modes.to_csv(index=False).encode("utf-8"),
    "fidelity_modes.csv",
    "text/csv",
)

# ======================================================
# DELTA SWEEP
# ======================================================

st.subheader("Average Fidelity vs Δt")

if network_type == "Intercity (Chain)":
    chain_delta_best, chain_delta_worst = delta_sweep_cached(
        "chain",
        tuple(map(float, delta_values)),
        n_nodes,
        m,
        distance_per_link,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        model_type,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )
    fig_delta, ax_delta = plt.subplots(figsize=(10, 6))
    ax_delta.plot(delta_values, chain_delta_best, color=COLOR_CHAIN_MAX, label="Chain Fmax")
    ax_delta.plot(delta_values, chain_delta_worst, color=COLOR_CHAIN_MIN, label="Chain Fmin")
    ax_delta.set_xlabel("Δt unit (ms)")
    ax_delta.set_ylabel("Average Fidelity")
    ax_delta.set_title("Intercity (Chain) — Average Fidelity vs Δt")
    ax_delta.grid(True, linestyle="--", alpha=0.3)
    ax_delta.legend()
    apply_normal_axis_format(ax_delta)
    st.pyplot(fig_delta, clear_figure=True)
    df_delta = pd.DataFrame({"Delta_t_unit_ms": delta_values, "Chain_Fmax": chain_delta_best, "Chain_Fmin": chain_delta_worst})
else:
    star_delta_best, _ = delta_sweep_cached(
        "star",
        tuple(map(float, delta_values)),
        n_nodes,
        m,
        distance_per_link,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        model_type,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )
    fig_delta, ax_delta = plt.subplots(figsize=(10, 6))
    ax_delta.plot(delta_values, star_delta_best, color=COLOR_STAR, label="Star")
    ax_delta.set_xlabel("Δt unit (ms)")
    ax_delta.set_ylabel("Average Fidelity")
    ax_delta.set_title("Intracity (Star) — Average Fidelity vs Δt")
    ax_delta.grid(True, linestyle="--", alpha=0.3)
    ax_delta.legend()
    apply_normal_axis_format(ax_delta)
    st.pyplot(fig_delta, clear_figure=True)
    df_delta = pd.DataFrame({"Delta_t_unit_ms": delta_values, "Star": star_delta_best})

st.dataframe(df_delta, use_container_width=True)
st.download_button(
    "Download Delta Data (CSV)",
    df_delta.to_csv(index=False).encode("utf-8"),
    "fidelity_delta.csv",
    "text/csv",
)


# ======================================================
# DETAILED TABLES
# ======================================================

st.subheader("Detailed Tables")

if network_type == "Intercity (Chain)":
    tab1, tab2 = st.tabs(["Chain Fmax", "Chain Fmin"])
    with tab1:
        show_df = chain_df_max.drop(columns=["raw_path_nodes"])
        st.dataframe(show_df, use_container_width=True)
        st.download_button(
            "Download Chain Fmax Table",
            show_df.to_csv(index=False).encode("utf-8"),
            "chain_fmax_table.csv",
            "text/csv",
            key="fmax_csv",
        )
    with tab2:
        show_df = chain_df_min.drop(columns=["raw_path_nodes"])
        st.dataframe(show_df, use_container_width=True)
        st.download_button(
            "Download Chain Fmin Table",
            show_df.to_csv(index=False).encode("utf-8"),
            "chain_fmin_table.csv",
            "text/csv",
            key="fmin_csv",
        )
else:
    show_df = star_df.drop(columns=["raw_path_nodes"])
    st.dataframe(show_df, use_container_width=True)
    st.download_button(
        "Download Star Table",
        show_df.to_csv(index=False).encode("utf-8"),
        "star_table.csv",
        "text/csv",
        key="star_csv",
    )


# ======================================================
# MODEL 0 vs MODEL 1 vs MODEL 2 COMPARISON
# ======================================================

st.subheader("Model 0 vs Model 1 vs Model 2 — Average Fidelity vs Δt")
st.caption(f"Using m = {int(m_comparison)} (set in sidebar under Model Comparison Settings)")

if network_type == "Intercity (Chain)":
    m0_best, m0_worst, m1_best, m1_worst, m2_best, m2_worst = model_comparison_delta_sweep_cached(
        "chain",
        tuple(map(float, delta_values)),
        n_nodes,
        int(m_comparison),
        distance_per_link,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )

    df_cmp = pd.DataFrame({
        "Delta_t_unit_ms": delta_values,
        "M0_Chain_Fmax": m0_best,
        "M0_Chain_Fmin": m0_worst,
        "M1_Chain_Fmax": m1_best,
        "M1_Chain_Fmin": m1_worst,
        "M2_Chain_Fmax": m2_best,
        "M2_Chain_Fmin": m2_worst,
    })

    # ---- difference columns for debugging / export ----
    df_cmp["Diff_Fmax_M2_minus_M1"] = df_cmp["M2_Chain_Fmax"] - df_cmp["M1_Chain_Fmax"]
    df_cmp["Diff_Fmin_M2_minus_M1"] = df_cmp["M2_Chain_Fmin"] - df_cmp["M1_Chain_Fmin"]

    # ---- figure with full + zoomed view ----
    fig_cmp, (ax_cmp_full, ax_cmp_zoom) = plt.subplots(
        2, 1, figsize=(11, 10), sharex=True
    )

    # =========================
    # FULL VIEW
    # =========================
    ax_cmp_full.plot(delta_values, m0_best,  color="orange",     linestyle="-.", label="Model 0 — Chain Fmax")
    ax_cmp_full.plot(delta_values, m0_worst, color="blue",       linestyle="-.", label="Model 0 — Chain Fmin")

    ax_cmp_full.plot(delta_values, m1_best,  color="orange",     linestyle="-",  label="Model 1 — Chain Fmax")
    ax_cmp_full.plot(delta_values, m1_worst, color="blue",       linestyle="-",  label="Model 1 — Chain Fmin")

    ax_cmp_full.plot(delta_values, m2_best,  color="darkorange", linestyle="--", label="Model 2 — Chain Fmax")
    ax_cmp_full.plot(delta_values, m2_worst, color="steelblue",  linestyle="--", label="Model 2 — Chain Fmin")

    ax_cmp_full.set_title(f"Intercity (Chain) — Model 0 vs Model 1 vs Model 2 (m={int(m_comparison)})")
    ax_cmp_full.set_ylabel("Average Fidelity")
    ax_cmp_full.grid(True, linestyle="--", alpha=0.3)
    ax_cmp_full.legend()

    full_vals = list(m0_best) + list(m0_worst) + list(m1_best) + list(m1_worst) + list(m2_best) + list(m2_worst)
    full_y_min = min(full_vals)
    full_y_max = max(full_vals)
    full_margin = (full_y_max - full_y_min) * 0.08 if full_y_max > full_y_min else 0.01
    ax_cmp_full.set_ylim(full_y_min - full_margin, full_y_max + full_margin)
    apply_normal_axis_format(ax_cmp_full)

    # =========================
    # ZOOMED VIEW (Model 1 vs Model 2 only)
    # =========================
    ax_cmp_zoom.plot(delta_values, m1_best,  color="orange",     linestyle="-",  label="Model 1 — Chain Fmax")
    ax_cmp_zoom.plot(delta_values, m1_worst, color="blue",       linestyle="-",  label="Model 1 — Chain Fmin")

    ax_cmp_zoom.plot(delta_values, m2_best,  color="darkorange", linestyle="--", label="Model 2 — Chain Fmax")
    ax_cmp_zoom.plot(delta_values, m2_worst, color="steelblue",  linestyle="--", label="Model 2 — Chain Fmin")

    # Fill gap between Model 1 and Model 2
    ax_cmp_zoom.fill_between(delta_values, m1_best, m2_best, alpha=0.20)
    ax_cmp_zoom.fill_between(delta_values, m1_worst, m2_worst, alpha=0.20)

    start_x = delta_values[0]
    end_x = delta_values[-1]

    def annotate_point(ax, x, y, text, x_offset=8, y_offset=8):
        ax.annotate(
            f"{text:.4f}",
            xy=(x, y),
            xytext=(x_offset, y_offset),
            textcoords="offset points",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.8),
        )

    annotate_point(ax_cmp_zoom, start_x, m1_best[0],   m1_best[0],   8,   8)
    annotate_point(ax_cmp_zoom, end_x,   m1_best[-1],  m1_best[-1], -40,  8)

    annotate_point(ax_cmp_zoom, start_x, m1_worst[0],  m1_worst[0],  8,  -12)
    annotate_point(ax_cmp_zoom, end_x,   m1_worst[-1], m1_worst[-1], -40, -12)

    annotate_point(ax_cmp_zoom, start_x, m2_best[0],   m2_best[0],   8,   20)
    annotate_point(ax_cmp_zoom, end_x,   m2_best[-1],  m2_best[-1], -40,  20)

    annotate_point(ax_cmp_zoom, start_x, m2_worst[0],  m2_worst[0],  8,  -25)
    annotate_point(ax_cmp_zoom, end_x,   m2_worst[-1], m2_worst[-1], -40, -25)

    # Auto zoom only around Model 1 and Model 2
    zoom_vals = list(m1_best) + list(m1_worst) + list(m2_best) + list(m2_worst)
    zoom_y_min = min(zoom_vals)
    zoom_y_max = max(zoom_vals)
    zoom_margin = max((zoom_y_max - zoom_y_min) * 0.25, 0.002)
    ax_cmp_zoom.set_ylim(zoom_y_min - zoom_margin, zoom_y_max + zoom_margin)

    ax_cmp_zoom.set_title("Zoomed View — Model 1 vs Model 2")
    ax_cmp_zoom.set_xlabel("Δt unit (ms)")
    ax_cmp_zoom.set_ylabel("Average Fidelity")
    ax_cmp_zoom.grid(True, linestyle="--", alpha=0.3)
    ax_cmp_zoom.legend()
    apply_normal_axis_format(ax_cmp_zoom)

    fig_cmp.tight_layout()
    st.pyplot(fig_cmp, clear_figure=True)

else:
    m0_best, m0_worst, m1_best, m1_worst, m2_best, m2_worst = model_comparison_delta_sweep_cached(
        "star",
        tuple(map(float, delta_values)),
        n_nodes,
        int(m_comparison),
        distance_per_link,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )

    df_cmp = pd.DataFrame({
        "Delta_t_unit_ms": delta_values,
        "M0_Star": m0_best,
        "M1_Star": m1_best,
        "M2_Star": m2_best,
    })

    # ---- difference columns for debugging / export ----
    df_cmp["Diff_M2_minus_M1"] = df_cmp["M2_Star"] - df_cmp["M1_Star"]

    # ---- figure with full + zoomed view ----
    fig_cmp, (ax_cmp_full, ax_cmp_zoom) = plt.subplots(
        2, 1, figsize=(11, 10), sharex=True
    )

    # =========================
    # FULL VIEW
    # =========================
    ax_cmp_full.plot(delta_values, m0_best, color="green",     linestyle="-.", label="Model 0 — Star")
    ax_cmp_full.plot(delta_values, m1_best, color="green",     linestyle="-",  label="Model 1 — Star")
    ax_cmp_full.plot(delta_values, m2_best, color="darkgreen", linestyle="--", label="Model 2 — Star")

    ax_cmp_full.set_title(f"Intracity (Star) — Model 0 vs Model 1 vs Model 2 (m={int(m_comparison)})")
    ax_cmp_full.set_ylabel("Average Fidelity")
    ax_cmp_full.grid(True, linestyle="--", alpha=0.3)
    ax_cmp_full.legend()

    full_vals = list(m0_best) + list(m1_best) + list(m2_best)
    full_y_min = min(full_vals)
    full_y_max = max(full_vals)
    full_margin = (full_y_max - full_y_min) * 0.08 if full_y_max > full_y_min else 0.01
    ax_cmp_full.set_ylim(full_y_min - full_margin, full_y_max + full_margin)
    apply_normal_axis_format(ax_cmp_full)

    # =========================
    # ZOOMED VIEW (Model 1 vs Model 2 only)
    # =========================
    ax_cmp_zoom.plot(delta_values, m1_best, color="green",     linestyle="-",  label="Model 1 — Star")
    ax_cmp_zoom.plot(delta_values, m2_best, color="darkgreen", linestyle="--", label="Model 2 — Star")

    ax_cmp_zoom.fill_between(delta_values, m1_best, m2_best, alpha=0.20)

    start_x = delta_values[0]
    end_x   = delta_values[-1]

    def annotate_point_star(ax, x, y, text, x_offset=8, y_offset=8):
        ax.annotate(
            f"{text:.4f}",
            xy=(x, y),
            xytext=(x_offset, y_offset),
            textcoords="offset points",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.8),
        )

    annotate_point_star(ax_cmp_zoom, start_x, m1_best[0],  m1_best[0],   8,   8)
    annotate_point_star(ax_cmp_zoom, end_x,   m1_best[-1], m1_best[-1], -40,  8)
    annotate_point_star(ax_cmp_zoom, start_x, m2_best[0],  m2_best[0],   8,  20)
    annotate_point_star(ax_cmp_zoom, end_x,   m2_best[-1], m2_best[-1], -40, 20)

    zoom_vals   = list(m1_best) + list(m2_best)
    zoom_y_min  = min(zoom_vals)
    zoom_y_max  = max(zoom_vals)
    zoom_margin = max((zoom_y_max - zoom_y_min) * 0.25, 0.002)
    ax_cmp_zoom.set_ylim(zoom_y_min - zoom_margin, zoom_y_max + zoom_margin)

    ax_cmp_zoom.set_title("Zoomed View — Model 1 vs Model 2 (Star)")
    ax_cmp_zoom.set_xlabel("Δt unit (ms)")
    ax_cmp_zoom.set_ylabel("Average Fidelity")
    ax_cmp_zoom.grid(True, linestyle="--", alpha=0.3)
    ax_cmp_zoom.legend()
    apply_normal_axis_format(ax_cmp_zoom)

    fig_cmp.tight_layout()
    st.pyplot(fig_cmp, clear_figure=True)

# Optional summary metrics
if network_type == "Intercity (Chain)":
    c1, c2 = st.columns(2)
    c1.metric("Max Fmax Difference (M2 - M1)", f"{df_cmp['Diff_Fmax_M2_minus_M1'].max():.6f}")
    c2.metric("Max Fmin Difference (M2 - M1)", f"{df_cmp['Diff_Fmin_M2_minus_M1'].max():.6f}")
else:
    c1 = st.columns(1)[0]
    c1.metric("Max Difference (M2 - M1)", f"{df_cmp['Diff_M2_minus_M1'].max():.6f}")
st.dataframe(df_cmp, use_container_width=True)
st.download_button(
    "Download Model Comparison Data (CSV)",
    df_cmp.to_csv(index=False).encode("utf-8"),
    "model_comparison.csv",
    "text/csv",
    )

# ======================================================
# MODEL 0 QUANTUM ADVANTAGE ZONE (FIXED 5 NODES)
# ======================================================

st.subheader("Model 0 — Quantum Advantage Zone (Fixed 5 Nodes)")
st.caption(
    "This figure is generated for a fixed 5-node network. "
    "The swept parameters are adjacent-link distance and Δt. "
    "Quantum advantage is defined by F > 2/3."
)

qa_link_distance_values = np.linspace(
    qa_link_distance_min, qa_link_distance_max, int(qa_link_distance_points)
)
qa_delta_values = np.linspace(
    qa_delta_t_min, qa_delta_t_max, int(qa_delta_t_points)
)

qa_topology_name = "chain" if network_type == "Intercity (Chain)" else "star"

qa_fmax_grid, qa_fmin_grid, qa_adv_fmax_grid, qa_adv_fmin_grid = model0_quantum_advantage_zone_cached(
    topology_name=qa_topology_name,
    link_distance_tuple=tuple(map(float, qa_link_distance_values)),
    delta_tuple=tuple(map(float, qa_delta_values)),
    m_value=m,  # kept for consistency with your app, though Model 0 ignores it
    T_value=T,
    alpha_value=alpha,
    eta_d1_value=eta_d1,
    eta_d2_value=eta_d2,
    rho_value=rho,
    eta_mem_value=eta_mem,
    fiber_index_value=fiber_index,
    max_exact=int(max_exact_orders),
    sample_count=int(sample_orders),
    seed=int(random_seed),
)

if network_type == "Intercity (Chain)":
    fig_qa, (ax_qa1, ax_qa2) = plt.subplots(2, 1, figsize=(11, 10), sharex=True)

    # -------- Fmax^avg advantage map --------
    im1 = ax_qa1.imshow(
        qa_adv_fmax_grid,
        origin="lower",
        aspect="auto",
        extent=[
            qa_link_distance_values[0],
            qa_link_distance_values[-1],
            qa_delta_values[0],
            qa_delta_values[-1],
        ],
    )

    contour1 = ax_qa1.contour(
        qa_link_distance_values,
        qa_delta_values,
        qa_fmax_grid,
        levels=[2.0 / 3.0],
        linewidths=2,
    )

    ax_qa1.clabel(contour1, fmt={2.0 / 3.0: "Fmax^avg = 2/3"}, inline=True, fontsize=9)
    ax_qa1.set_ylabel("Δt unit (ms)")
    ax_qa1.set_title("Model 0 — Chain Quantum Advantage Zone using $F_{max}^{avg}$")
    cbar1 = plt.colorbar(im1, ax=ax_qa1)
    cbar1.set_ticks([0, 1])
    cbar1.set_ticklabels(["No Advantage", "Advantage"])

    # -------- Fmin^avg advantage map --------
    im2 = ax_qa2.imshow(
        qa_adv_fmin_grid,
        origin="lower",
        aspect="auto",
        extent=[
            qa_link_distance_values[0],
            qa_link_distance_values[-1],
            qa_delta_values[0],
            qa_delta_values[-1],
        ],
    )

    contour2 = ax_qa2.contour(
        qa_link_distance_values,
        qa_delta_values,
        qa_fmin_grid,
        levels=[2.0 / 3.0],
        linewidths=2,
    )

    ax_qa2.clabel(contour2, fmt={2.0 / 3.0: "Fmin^avg = 2/3"}, inline=True, fontsize=9)
    ax_qa2.set_xlabel("Distance between adjacent nodes (km)")
    ax_qa2.set_ylabel("Δt unit (ms)")
    ax_qa2.set_title("Model 0 — Chain Quantum Advantage Zone using $F_{min}^{avg}$")
    cbar2 = plt.colorbar(im2, ax=ax_qa2)
    cbar2.set_ticks([0, 1])
    cbar2.set_ticklabels(["No Advantage", "Advantage"])

    fig_qa.tight_layout()
    st.pyplot(fig_qa, clear_figure=True)

    qa_df_fmax = pd.DataFrame(
        qa_fmax_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )
    qa_df_fmin = pd.DataFrame(
        qa_fmin_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )
    qa_df_adv_fmax = pd.DataFrame(
        qa_adv_fmax_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )
    qa_df_adv_fmin = pd.DataFrame(
        qa_adv_fmin_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )

    st.markdown("#### Model 0 — Chain $F_{max}^{avg}$ Values")
    st.dataframe(qa_df_fmax, use_container_width=True)

    st.markdown("#### Model 0 — Chain $F_{min}^{avg}$ Values")
    st.dataframe(qa_df_fmin, use_container_width=True)

    st.markdown("#### Model 0 — Chain Advantage Map using $F_{max}^{avg}$")
    st.dataframe(qa_df_adv_fmax, use_container_width=True)

    st.markdown("#### Model 0 — Chain Advantage Map using $F_{min}^{avg}$")
    st.dataframe(qa_df_adv_fmin, use_container_width=True)

    st.download_button(
        "Download Model 0 Chain Fmax^avg Grid (CSV)",
        qa_df_fmax.to_csv(index=True).encode("utf-8"),
        "model0_chain_fmax_avg_grid.csv",
        "text/csv",
        key="model0_chain_fmax_avg_grid_csv",
    )

    st.download_button(
        "Download Model 0 Chain Fmin^avg Grid (CSV)",
        qa_df_fmin.to_csv(index=True).encode("utf-8"),
        "model0_chain_fmin_avg_grid.csv",
        "text/csv",
        key="model0_chain_fmin_avg_grid_csv",
    )

    st.download_button(
        "Download Model 0 Chain Advantage Fmax^avg Map (CSV)",
        qa_df_adv_fmax.to_csv(index=True).encode("utf-8"),
        "model0_chain_adv_fmax_avg_map.csv",
        "text/csv",
        key="model0_chain_adv_fmax_avg_map_csv",
    )

    st.download_button(
        "Download Model 0 Chain Advantage Fmin^avg Map (CSV)",
        qa_df_adv_fmin.to_csv(index=True).encode("utf-8"),
        "model0_chain_adv_fmin_avg_map.csv",
        "text/csv",
        key="model0_chain_adv_fmin_avg_map_csv",
    )

else:
    fig_qa, ax_qa = plt.subplots(figsize=(11, 6))

    im = ax_qa.imshow(
        qa_adv_fmax_grid,
        origin="lower",
        aspect="auto",
        extent=[
            qa_link_distance_values[0],
            qa_link_distance_values[-1],
            qa_delta_values[0],
            qa_delta_values[-1],
        ],
    )

    contour = ax_qa.contour(
        qa_link_distance_values,
        qa_delta_values,
        qa_fmax_grid,
        levels=[2.0 / 3.0],
        linewidths=2,
    )

    ax_qa.clabel(contour, fmt={2.0 / 3.0: "Favg = 2/3"}, inline=True, fontsize=9)
    ax_qa.set_xlabel("Distance between adjacent nodes (km)")
    ax_qa.set_ylabel("Δt unit (ms)")
    ax_qa.set_title("Model 0 — Star Quantum Advantage Zone using $F^{avg}$")

    cbar = plt.colorbar(im, ax=ax_qa)
    cbar.set_ticks([0, 1])
    cbar.set_ticklabels(["No Advantage", "Advantage"])

    st.pyplot(fig_qa, clear_figure=True)

    qa_df_favg = pd.DataFrame(
        qa_fmax_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )
    qa_df_adv_favg = pd.DataFrame(
        qa_adv_fmax_grid,
        index=np.round(qa_delta_values, 4),
        columns=np.round(qa_link_distance_values, 4),
    )

    st.markdown("#### Model 0 — Star $F^{avg}$ Values")
    st.dataframe(qa_df_favg, use_container_width=True)

    st.markdown("#### Model 0 — Star Advantage Map using $F^{avg}$")
    st.dataframe(qa_df_adv_favg, use_container_width=True)

    st.download_button(
        "Download Model 0 Star Favg Grid (CSV)",
        qa_df_favg.to_csv(index=True).encode("utf-8"),
        "model0_star_favg_grid.csv",
        "text/csv",
        key="model0_star_favg_grid_csv",
    )

    st.download_button(
        "Download Model 0 Star Advantage Map (CSV)",
        qa_df_adv_favg.to_csv(index=True).encode("utf-8"),
        "model0_star_adv_map.csv",
        "text/csv",
        key="model0_star_adv_map_csv",
    )

# ======================================================
# MULTI-NODE STAR SWEEP
# ======================================================

if network_type == "Intracity (Star)":
    st.subheader("Star Average Fidelity vs Δt — Multiple Node Counts")

    multi_node_results = multi_node_delta_sweep_cached(
        tuple(multi_node_values),
        tuple(map(float, delta_values)),
        m,
        total_distance,
        T,
        alpha,
        eta_d1,
        eta_d2,
        rho,
        eta_mem,
        fiber_index,
        model_type,
        int(max_exact_orders),
        int(sample_orders),
        int(random_seed),
    )

    colors_multi = plt.cm.tab10.colors
    fig_multi, ax_multi = plt.subplots(figsize=(12, 7))
    for i, n in enumerate(multi_node_values):
        ax_multi.plot(
            delta_values,
            multi_node_results[n],
            marker="o",
            markersize=3,
            color=colors_multi[i % len(colors_multi)],
            label=f"{n} nodes (L={total_distance/(n-1):.1f} km/link)",
        )
    ax_multi.set_xlabel("Δt unit (ms)")
    ax_multi.set_ylabel("Average Fidelity")
    ax_multi.set_title(f"Intracity (Star) — Average Fidelity vs Δt for Different Node Counts (Total distance = {total_distance:.1f} km)")
    ax_multi.grid(True, linestyle="--", alpha=0.3)
    ax_multi.legend()
    apply_normal_axis_format(ax_multi)
    st.pyplot(fig_multi, clear_figure=True)

    df_multi = pd.DataFrame({"Delta_t_unit_ms": delta_values})
    for n in multi_node_values:
        df_multi[f"Star_{n}_nodes"] = multi_node_results[n]
    st.dataframe(df_multi, use_container_width=True)
    st.download_button(
        "Download Multi-Node Star Data (CSV)",
        df_multi.to_csv(index=False).encode("utf-8"),
        "star_multi_node.csv",
        "text/csv",
    )

# ======================================================
# P_SUCCESS vs FIXED TOTAL DISTANCE
# ======================================================

# ======================================================
# 5-NODE CHAIN: p_elem^n vs TOTAL DISTANCE
# ======================================================

st.subheader("5-Node Chain: Elementary-Link Term vs Total Distance")
st.caption("Model 1 uses p_elem^(N-1)=p_elem^4. Model 2 uses p_elem^n_links for different path lengths in a 5-node chain.")

fixed_total_distances = [100, 150, 200, 250, 300, 350, 400, 450, 500]

# For a 5-node chain, total number of elementary links = 4
n_elem = 4

p_elem_values = []
model1_vals = []
model2_len1 = []
model2_len2 = []
model2_len3 = []
model2_len4 = []

for total_dist in fixed_total_distances:
    # 5-node chain => 4 links
    distance_per_link_here = total_dist / 4

    p_single_here = (eta_d1 ** 2) * (rho ** 2) * 10 ** (-alpha * distance_per_link_here / 10)
    p_elem_here = 1 - (1 - p_single_here) ** m

    p_elem_values.append(p_elem_here)

    # Model 1
    model1_vals.append(p_elem_here ** n_elem)

    # Model 2 for different path lengths
    model2_len1.append(p_elem_here ** 1)
    model2_len2.append(p_elem_here ** 2)
    model2_len3.append(p_elem_here ** 3)
    model2_len4.append(p_elem_here ** 4)

fig_chain_elem, ax_chain_elem = plt.subplots(figsize=(10, 6))

# Model 1
ax_chain_elem.plot(
    fixed_total_distances,
    model1_vals,
    marker="o",
    linestyle="-",
    linewidth=2,
    color="black",
    label=r"Model 1: $p_{elem}^{4}$"
)

# Model 2
ax_chain_elem.plot(
    fixed_total_distances,
    model2_len1,
    marker="s",
    linestyle="--",
    linewidth=2,
    label=r"Model 2: $p_{elem}^{1}$"
)
ax_chain_elem.plot(
    fixed_total_distances,
    model2_len2,
    marker="s",
    linestyle="--",
    linewidth=2,
    label=r"Model 2: $p_{elem}^{2}$"
)
ax_chain_elem.plot(
    fixed_total_distances,
    model2_len3,
    marker="s",
    linestyle="--",
    linewidth=2,
    label=r"Model 2: $p_{elem}^{3}$"
)
ax_chain_elem.plot(
    fixed_total_distances,
    model2_len4,
    marker="s",
    linestyle="--",
    linewidth=2,
    label=r"Model 2: $p_{elem}^{4}$"
)

ax_chain_elem.set_xlabel("Total Distance (km)")
ax_chain_elem.set_ylabel("Elementary-link term")
ax_chain_elem.set_title("5-Node Chain: Model 1 vs Model 2 Elementary-Link Terms")
ax_chain_elem.grid(True, linestyle="--", alpha=0.3)
ax_chain_elem.legend()

# Optional if values get very small:
# ax_chain_elem.set_yscale("log")

st.pyplot(fig_chain_elem, clear_figure=True)

df_chain_elem = pd.DataFrame({
    "Total_Distance_km": fixed_total_distances,
    "p_elem": p_elem_values,
    "Model1_p_elem_pow_4": model1_vals,
    "Model2_p_elem_pow_1": model2_len1,
    "Model2_p_elem_pow_2": model2_len2,
    "Model2_p_elem_pow_3": model2_len3,
    "Model2_p_elem_pow_4": model2_len4,
})

st.dataframe(df_chain_elem, use_container_width=True)

st.download_button(
    "Download 5-Node Chain Elementary-Link Data (CSV)",
    df_chain_elem.to_csv(index=False).encode("utf-8"),
    "chain_5node_p_elem_terms.csv",
    "text/csv",
)
# ======================================================
# DEBUG TABLE
# ======================================================

st.subheader("Δt Sweep Debug Table")
st.dataframe(df_delta, use_container_width=True)


# ======================================================
# EXCEL EXPORT
# ======================================================

st.subheader("Excel Export")

if network_type == "Intercity (Chain)":
    excel_bytes = make_excel_bytes(
        {
            "summary": pd.DataFrame(
                {
                    "Metric": ["Chain Fmax", "Chain Fmin", "t0_ms"],
                    "Value": [chain_fmax, chain_fmin, t0],
                }
            ),
            "modes": df_modes,
            "delta": df_delta,
            "chain_fmax": chain_df_max.drop(columns=["raw_path_nodes"]),
            "chain_fmin": chain_df_min.drop(columns=["raw_path_nodes"]),
        }
    )
else:
    excel_bytes = make_excel_bytes(
        {
            "summary": pd.DataFrame(
                {
                    "Metric": ["Star Fidelity", "t0_ms"],
                    "Value": [star_avg, t0],
                }
            ),
            "modes": df_modes,
            "delta": df_delta,
            "star": star_df.drop(columns=["raw_path_nodes"]),
        }
    )

if excel_bytes is not None:
    st.download_button(
        "Download Excel Workbook",
        excel_bytes,
        "quantum_network_results.xlsx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
else:
    st.info("Excel export not available because openpyxl is not installed.")
