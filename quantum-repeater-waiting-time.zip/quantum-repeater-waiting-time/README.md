# Quantum Repeater Waiting-Time Models

Code and generated paper figures for comparing two quantum-repeater memory waiting-time treatments:

- `layered/` — layered waiting-time model
- `max_wait/` — maximum-wait-time model

Each model folder contains:

- application code (`*_app.py`)
- paper figure generator (`generate_paper_figures.py`)
- generated CSV data (`figure_data/`)
- generated PNG/PDF figures (`paper_figures/`)
- `GRAPH_MANIFEST.json`

## Install

```bash
python -m pip install -r requirements.txt
```

## Run the applications

```bash
streamlit run layered/layered_app.py
streamlit run max_wait/max_wait_app.py
```

## Regenerate paper figures

```bash
python layered/generate_paper_figures.py
python max_wait/generate_paper_figures.py
```

## Model convention

The repository uses `n` for the number of elementary links, so a path has `n+1` nodes and `n-1` intermediate swapping operations. The final corrected implementations use the same swapping-success convention in both models and do not apply an additional path-level power to `p_success` in the fidelity calculation.
