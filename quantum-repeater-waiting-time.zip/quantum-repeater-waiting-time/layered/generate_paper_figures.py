WAIT_MODEL='layered'
from pathlib import Path
import itertools, math, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.patches import Rectangle
rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'mathtext.fontset':'cm','axes.linewidth':0.8,'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True,'xtick.minor.visible':True,'ytick.minor.visible':True})

OUT=Path(__file__).resolve().parent
FIGDIR=OUT/'paper_figures'; DATADIR=OUT/'figure_data'
FIGDIR.mkdir(exist_ok=True); DATADIR.mkdir(exist_ok=True)
N=5; ALPHA=0.21; T_MS=200.0; ETA_D1=0.95; ETA_D2=0.95; RHO=0.9; ETA_MEM=0.95; T0_MS=0.0
THRESHOLD=2/3

def p_elem(distance_km,m):
    ps=(ETA_D1**2)*(RHO**2)*10**(-ALPHA*np.asarray(distance_km,dtype=float)/10)
    return 1-(1-ps)**int(m)

def p_swap(n):
    return 1.0 if n<=1 else (ETA_MEM*ETA_D2)**(2*(n-1))

def chain_paths():
    return [(i,j,list(range(i,j+1))) for i in range(N) for j in range(i+1,N)]

def star_paths():
    out=[]
    for i in range(1,N): out.append((0,i,[0,i]))
    for a in range(1,N):
        for b in range(a+1,N): out.append((a,b,[a,0,b]))
    return out

def eval_order(order):
    node_wait={}; rows=[]
    for u,v,p in order:
        waits=[]; contrib={}
        for node in p[1:-1]:
            w=node_wait.get(node,0); waits.append(w); contrib[node]=w; node_wait[node]=w+1
        rows.append((p,len(p)-1,max(waits) if waits else 0,contrib))
    return rows

def reduced_orders(paths):
    zero=sorted([x for x in paths if len(x[2])<=2],key=lambda x:(x[0],x[1]))
    conflict=sorted([x for x in paths if len(x[2])>2],key=lambda x:(x[0],x[1]))
    return [zero+list(p) for p in itertools.permutations(conflict)]

def layered_slots(path_nodes,contrib):
    n=len(path_nodes)-1
    if n<=1: return 0.0
    segments=[{'left':i,'right':i+1,'created_at':0.0} for i in range(n)]
    events=[{'boundary':b,'time':float(contrib.get(node,0))} for b,node in enumerate(path_nodes[1:-1],1)]
    events.sort(key=lambda e:(e['time'],e['boundary']))
    total=0.0
    def possible(e):
        b=e['boundary']
        return any(s['right']==b for s in segments) and any(s['left']==b for s in segments)
    def layer(evts):
        ordered=sorted(evts,key=lambda e:e['boundary']); best=[]
        for parity in (1,0):
            cand=[]; blocked=set()
            for e in ordered:
                b=e['boundary']
                if b%2!=parity or b in blocked: continue
                cand.append(e); blocked.update({b-1,b,b+1})
            if len(cand)>len(best): best=cand
        return best or ([ordered[0]] if ordered else [])
    rem=list(events)
    while rem:
        t=min(e['time'] for e in rem)
        while True:
            elig=[e for e in rem if e['time']<=t and possible(e)]
            if not elig: break
            for e in layer(elig):
                b=e['boundary']; L=next(s for s in segments if s['right']==b); R=next(s for s in segments if s['left']==b)
                total += max(0,t-L['created_at'])+max(0,t-R['created_at'])
                new={'left':L['left'],'right':R['right'],'created_at':t}
                segments=[s for s in segments if s is not L and s is not R]+[new]; segments.sort(key=lambda s:(s['left'],s['right']))
                rem.remove(e)
            if not any(e['time']<=t and possible(e) for e in rem): break
    return total

def precompute(topology):
    paths=chain_paths() if topology=='chain' else star_paths(); nrows=[]; durows=[]
    for order in reduced_orders(paths):
        ns=[]; dus=[]
        for path,n,w,c in eval_order(order):
            du=n*w if WAIT_MODEL=='max' else layered_slots(path,c)
            ns.append(n); dus.append(float(du))
        nrows.append(ns); durows.append(dus)
    return np.asarray(nrows,dtype=int), np.asarray(durows,dtype=float)
CHAIN=precompute('chain'); STAR=precompute('star')

def averages(topology,model,d,m,dt):
    pe=float(p_elem(d,m)); nmat,dumat=CHAIN if topology=='chain' else STAR
    if model=='Model 0':
        ps=np.ones_like(nmat,dtype=float)
    else:
        swaps=np.where(nmat<=1,1.0,(ETA_MEM*ETA_D2)**(2*(nmat-1)))
        if model=='Model 1':
            gen=pe**(N-1)
        else:
            gen=pe**nmat
        ps=gen*swaps
    dec=np.exp(-(dumat*float(dt))/T_MS)
    order_avg=np.mean((1.0+ps*dec)/2.0,axis=1)
    if topology=='star':
        v=float(np.mean(order_avg)); return v,v
    return float(np.max(order_avg)),float(np.min(order_avg))

def save(df,name): df.to_csv(DATADIR/name,index=False)

def fig5():
    dts=np.linspace(0,200,101); rows=[]
    fig,axs=plt.subplots(1,3,figsize=(15,4.3),sharey=True)
    gold='#E69F00'; blue='#4C78A8'
    for ax,model in zip(axs,['Model 0','Model 1','Model 2']):
        hi=[]; lo=[]
        for dt in dts:
            a,b=averages('chain',model,100,1000,float(dt)); hi.append(a); lo.append(b); rows.append([model,dt,a,b])
        ax.plot(dts,hi,color=gold,linewidth=1.5,label=r'$F^{avg}_{max}$')
        ax.plot(dts,lo,color=blue,linewidth=1.35,linestyle='--',label=r'$F^{avg}_{min}$')
        ax.set_title(model,fontsize=10)
        ax.set_xlabel(r'Waiting interval, $\delta_t$ (ms)',fontsize=9)
        ax.grid(True,linestyle='-',linewidth=.45,alpha=.22)
        ax.set_xlim(0,200); ax.set_ylim(.65,1.01); ax.tick_params(labelsize=8)
    axs[0].set_ylabel('Average Fidelity',fontsize=9)
    axs[1].legend(loc='upper center',bbox_to_anchor=(.5,1.20),ncol=2,frameon=False,fontsize=9)
    fig.tight_layout(pad=1.0,w_pad=.8)
    for ext in ('png','pdf'): fig.savefig(FIGDIR/f'Fig5_chain_Favg_vs_delta.{ext}',dpi=300 if ext=='png' else None,bbox_inches='tight')
    plt.close(fig); save(pd.DataFrame(rows,columns=['model','delta_t_ms','Favg_max','Favg_min']),'Fig5_chain_Favg_vs_delta.csv')
def chain_heatmaps():
    modes=[10,250,500,1000]; ds=np.linspace(1,200,90); dts=np.linspace(0,200,90); rows=[]
    levels=np.linspace(0.50,0.92,8)
    fig=plt.figure(figsize=(17.6,5.35))
    outer=fig.add_gridspec(1,2,left=.055,right=.965,bottom=.13,top=.88,wspace=.12)
    for mi,model in enumerate(['Model 1','Model 2']):
        inner=outer[mi].subgridspec(2,5,width_ratios=[1,1,1,1,.055],wspace=.18,hspace=.30)
        axes=[]; cf=None; grids={}
        for m in modes:
            z1=np.zeros((len(dts),len(ds))); z2=np.zeros_like(z1)
            for iy,dt in enumerate(dts):
                for ix,d in enumerate(ds):
                    a,b=averages('chain',model,float(d),m,float(dt)); z1[iy,ix]=a; z2[iy,ix]=b; rows.append([model,m,d,dt,a,b])
            grids[m]=(z1,z2)
        for r in range(2):
            for j,m in enumerate(modes):
                ax=fig.add_subplot(inner[r,j]); axes.append(ax); z=grids[m][r]
                cf=ax.contourf(ds,dts,z,levels=levels,cmap='cividis',extend='max')
                if z.min()<=THRESHOLD<=z.max():
                    ax.contour(ds,dts,z,levels=[THRESHOLD],colors='white',linewidths=1.05,linestyles='--')
                if r==0: ax.set_title(rf'$m={m}$',fontsize=8.5,pad=4)
                if r==1: ax.set_xlabel('Distance (km)',fontsize=7.5,labelpad=2)
                if j==0:
                    prefix=(r'$F^{avg}_{max}$' if r==0 else r'$F^{avg}_{min}$')
                    ax.set_ylabel(prefix+'\n'+r'Waiting interval, $\delta_t$ (ms)',fontsize=7.5,labelpad=4)
                ax.set_xlim(0,200); ax.set_ylim(0,200)
                ax.tick_params(axis='both',which='both',labelsize=6.5,length=2,direction='in',top=True,right=True)
                for spine in ax.spines.values():
                    spine.set_visible(True); spine.set_color('black'); spine.set_linewidth(1.15)
        cax=fig.add_subplot(inner[:,4])
        cb=fig.colorbar(cf,cax=cax,ticks=levels)
        cb.ax.tick_params(labelsize=6.5)
        for spine in cax.spines.values():
            spine.set_visible(True); spine.set_color('black'); spine.set_linewidth(0.8)
        pos=outer[mi].get_position(fig)
        fig.text((pos.x0+pos.x1)/2,.925,('Intercity Network '+model),ha='center',va='center',fontsize=9.5,fontweight='bold')
    for ext in ('png','pdf'):
        fig.savefig(FIGDIR/f'Fig6_chain_quantum_advantage.{ext}',dpi=300 if ext=='png' else None,bbox_inches='tight',pad_inches=.08)
    plt.close(fig); save(pd.DataFrame(rows,columns=['model','m','distance_km','delta_t_ms','Favg_max','Favg_min']),'Fig6_chain_quantum_advantage.csv')

def fig8():
    dts=np.linspace(0,200,101); rows=[]; fig,ax=plt.subplots(figsize=(7.4,4.7))
    styles={'Model 0':('#8172B2','-'),'Model 1':('#E69F00','-'),'Model 2':('#E76F51','-')}
    for model in ['Model 0','Model 1','Model 2']:
        vals=[]
        for dt in dts:
            a,_=averages('star',model,20,10,float(dt)); vals.append(a); rows.append([model,dt,a])
        color,ls=styles[model]; ax.plot(dts,vals,color=color,linestyle=ls,linewidth=1.5,label=model)
    ax.set_xlabel(r'Waiting interval, $\delta_t$ (ms)',fontsize=9); ax.set_ylabel('Average Fidelity',fontsize=9)
    ax.set_xlim(0,200); ax.set_ylim(.5,1.01); ax.grid(True,linestyle='-',linewidth=.45,alpha=.22); ax.legend(loc='upper right',fontsize=8,frameon=True)
    ax.tick_params(labelsize=8); fig.tight_layout()
    for ext in ('png','pdf'): fig.savefig(FIGDIR/f'Fig8_star_Favg_vs_delta.{ext}',dpi=300 if ext=='png' else None,bbox_inches='tight')
    plt.close(fig); save(pd.DataFrame(rows,columns=['model','delta_t_ms','Favg']),'Fig8_star_Favg_vs_delta.csv')
def star_heatmaps():
    modes=[1,5,10,20,35,50]; ds=np.linspace(10,40,90); dts=np.linspace(0,200,90); rows=[]
    levels=np.linspace(0.50,0.92,8)
    fig=plt.figure(figsize=(15.8,5.35))
    outer=fig.add_gridspec(1,2,left=.06,right=.965,bottom=.14,top=.88,wspace=.12)
    for mi,model in enumerate(['Model 1','Model 2']):
        inner=outer[mi].subgridspec(2,4,width_ratios=[1,1,1,.06],wspace=.19,hspace=.31)
        axes=[]; cf=None; grids={}
        for m in modes:
            z=np.zeros((len(dts),len(ds)))
            for iy,dt in enumerate(dts):
                for ix,d in enumerate(ds):
                    a,_=averages('star',model,float(d),m,float(dt)); z[iy,ix]=a; rows.append([model,m,d,dt,a])
            grids[m]=z
        for k,m in enumerate(modes):
            ax=fig.add_subplot(inner[k//3,k%3]); axes.append(ax); z=grids[m]
            cf=ax.contourf(ds,dts,z,levels=levels,cmap='cividis',extend='max')
            if z.min()<=THRESHOLD<=z.max():
                ax.contour(ds,dts,z,levels=[THRESHOLD],colors='white',linewidths=1.05,linestyles='--')
            ax.set_title(rf'$m={m}$',fontsize=8.5,pad=4)
            if k//3==1: ax.set_xlabel('Hub-to-leaf distance (km)',fontsize=7.5,labelpad=2)
            if k%3==0: ax.set_ylabel(r'Waiting interval, $\delta_t$ (ms)',fontsize=7.5,labelpad=4)
            ax.set_xlim(10,40); ax.set_ylim(0,200)
            ax.set_xticks([10,15,20,25,30,35,40])
            ax.tick_params(axis='both',which='both',labelsize=6.5,length=2,direction='in',top=True,right=True)
            for spine in ax.spines.values():
                spine.set_visible(True); spine.set_color('black'); spine.set_linewidth(1.15)
        cax=fig.add_subplot(inner[:,3])
        cb=fig.colorbar(cf,cax=cax,ticks=levels)
        cb.ax.tick_params(labelsize=6.5)
        for spine in cax.spines.values():
            spine.set_visible(True); spine.set_color('black'); spine.set_linewidth(0.8)
        pos=outer[mi].get_position(fig)
        fig.text((pos.x0+pos.x1)/2,.925,('Metropolitan Network '+model),ha='center',va='center',fontsize=9.5,fontweight='bold')
    for ext in ('png','pdf'):
        fig.savefig(FIGDIR/f'Fig9_star_quantum_advantage.{ext}',dpi=300 if ext=='png' else None,bbox_inches='tight',pad_inches=.08)
    plt.close(fig); save(pd.DataFrame(rows,columns=['model','m','distance_km','delta_t_ms','Favg']),'Fig9_star_quantum_advantage.csv')

def crit_curves(topology,model,modes,Ds,thr=.99):
    exps=([N-1] if model=='Model 1' else [1,2,3,4]) if topology=='chain' else ([2] if model=='Model 1' else [1,2])
    out={e:[] for e in exps}
    for m in modes:
        for e in exps:
            valid=[D for D in Ds if float(p_elem(D/(N-1),m))**e>=thr]; out[e].append(max(valid) if valid else np.nan)
    return out

def crit(topology,fname):
    modes=np.unique(np.round(np.logspace(1,4,120)).astype(int)); anchors=[10,50,100,500,1000,2000,5000,10000]; Ds=np.linspace(10,650,1281); rows=[]
    fig,axs=plt.subplots(1,2,figsize=(13,5),sharey=True)
    style_by_exp={1:('#9ACD32','-','D'),2:('#4C78A8','--','D'),3:('#F28E2B','--','o'),4:('#E15759',':','o')}
    for ax,model in zip(axs,['Model 1','Model 2']):
        curves=crit_curves(topology,model,modes,Ds)
        anchor_curves=crit_curves(topology,model,np.array(anchors),Ds)
        for e,vals in curves.items():
            if model=='Model 1': color,ls,mk=('#9ACD32','-','D')
            else: color,ls,mk=style_by_exp[e]
            label=(rf'{model}: $P_{{link}}\geq0.99$' if model=='Model 1' else rf'{model}: $p_{{elem}}^{{{e}}}\geq0.99$')
            ax.plot(modes,vals,label=label,color=color,linestyle=ls,linewidth=1.35)
            ax.plot(anchors,anchor_curves[e],linestyle='None',marker=mk,markersize=4.0,color=color,markeredgewidth=0.0)
            rows += [[topology,model,e,int(m),v] for m,v in zip(modes,vals)]
        ax.set_xscale('log'); ax.set_title(model,fontsize=9); ax.set_xlabel('Multiplexing modes, $m$',fontsize=8)
        ax.grid(True,which='both',linestyle=':',linewidth=.45,alpha=.28); ax.legend(fontsize=7,loc='upper left',frameon=True)
        ax.set_xticks(anchors); ax.set_xticklabels([str(x) for x in anchors],fontsize=7); ax.tick_params(axis='y',labelsize=7)
        for spine in ax.spines.values():
            spine.set_visible(True); spine.set_color('black'); spine.set_linewidth(1.0)
    axs[0].set_ylabel('Critical total distance (km)',fontsize=8); fig.tight_layout(rect=[.025,.035,.975,.965])
    fig.add_artist(Rectangle((.012,.025),.976,.95,transform=fig.transFigure,fill=False,edgecolor='black',linewidth=1.15,clip_on=False,zorder=0))
    for ext in ('png','pdf'): fig.savefig(FIGDIR/f'{fname}.{ext}',dpi=300 if ext=='png' else None,bbox_inches='tight',pad_inches=.06)
    plt.close(fig); save(pd.DataFrame(rows,columns=['topology','model','exponent','m','critical_total_distance_km']),f'{fname}.csv')

def main():
    fig5(); chain_heatmaps(); fig8(); star_heatmaps(); crit('chain','Fig10_chain_critical_distance'); crit('star','Fig11_star_critical_distance')
    manifest={'wait_model':WAIT_MODEL,'t0_ms':0.0,'swap_formula':'(eta_mem * eta_d2) ** (2 * (n_links - 1))','parameters':{'N':N,'alpha':ALPHA,'T_ms':T_MS,'eta_d1':ETA_D1,'eta_d2':ETA_D2,'rho':RHO,'eta_mem':ETA_MEM},'fig5':{'chain_total_km':400,'link_km':100,'m':1000},'fig6':{'modes':[10,250,500,1000],'distance_is_adjacent_link_km':[1,200],'delta_ms':[0,200]},'fig8':{'star_total_scale_km':80,'hub_leaf_km':20,'m':10},'fig9':{'modes':[1,5,10,20,35,50],'hub_leaf_km':[10,40],'delta_ms':[0,200]},'critical_distance_note':'Retains existing app criterion p_elem^exponent >= 0.99, matching current paper figure legends.'}
    (OUT/'GRAPH_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    print('Generated',WAIT_MODEL,'figures in',FIGDIR)
if __name__=='__main__': main()
